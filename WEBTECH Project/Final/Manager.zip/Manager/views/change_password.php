<?php 
    
    include_once('session_user.php');

    if($_SESSION['user_type'] == 'manager')
    {
        foreach( $managers as $manager )
        {
            if( $uname == $manager['uname'] )
            {
            	$a_uname = $manager['uname'];
            	$user    = getUser($uname);
            	$_SESSION['id']       = $user['id'];
            	$_SESSION['name']     = $user['name'];
            	$_SESSION['uname']    = $user['uname'];
            	$_SESSION['status']   = $user['status'];
            }
        }
    }

    $password='';
    $err_password='';
    $n_password='';
    $err_n_password='';
    $c_password='';
    $err_c_password='';

    if(isset($_POST['update_password']))
    {
    	if(empty($_POST['password']))
		{
			$err_password="*Password Required";
			$has_error=true;
		}
		else
		{
			if(sha1($_POST['password']) != $user['password'])
			{
				$err_password="*Password Wrong";
				$password=htmlspecialchars($_POST['password']);  
				$has_error=true;
			}

			else
			{
				$password=htmlspecialchars($_POST['password']);
			}
		}
		if(empty($_POST['n_password']))
		{
			$err_n_password="*New Password Required";
			$has_error=true;
		}
		else 
		{
			if ( $_POST['password'] == $_POST['n_password'])
			{
				$err_n_password="*Current Password & New Password Should be Different!!";
				$n_password=htmlspecialchars($_POST['n_password']);
				$has_error=true;
			}
			else
			{
				if ( !preg_match('@[^\w]@', $_POST['n_password'] ) )
				{
					$err_n_password="*Password must contain at least one of the special characters";
					$has_error=true;
					$n_password=htmlspecialchars($_POST['n_password']);
				}
				else
				{
					if(strlen($_POST['n_password']) < 8)
					{
						$err_n_password="*Password not be less than 8 characters";
						$has_error=true;
						$n_password=htmlspecialchars($_POST['n_password']);
					}
					else
					{
						$n_password=htmlspecialchars($_POST['n_password']);
					}
				}
			}
		}

		if(empty($_POST['c_password']))
		{
			$err_c_password="*Confirm Password Required";
			$has_error=true;
		}
		else
		{
			if( $_POST['n_password'] != $_POST['c_password'] )
			{
				$err_c_password="*New password and confirm password should be matched";
				$has_error=true;
			}
			else
			{
				$c_password=htmlspecialchars($_POST['c_password']);
				$_SESSION['password'] = sha1($c_password);
			}
		}

		if(!$has_error)
		{
			header("Location:../controllers/manager_Controller.php?req=change_pass");

		}
    }
    
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>

	<section class="col-md-8">

		<div class="container pt-5 pb-5">
			<h1 class="text-center pb-4">R E S E T &nbsp;&nbsp; P A S S W O R D</h1>
			<form action="" method="POST">
			  <div class="row mb-3">
			    <label for="password" class="col-sm-2 col-form-label">Current Password</label>
			    <div class="col-sm-10">
			      <input type="password" name="password" class="form-control" id="password" value="<?php echo $password; ?>">
			      <span style="color:red"><?php echo $err_password;?></span>
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="n_password" class="col-sm-2 col-form-label">New Password</label>
			    <div class="col-sm-10">
			      <input type="password" name="n_password" class="form-control" id="n_password" value="<?php echo $n_password; ?>">
			      <span style="color:red"><?php echo $err_n_password;?></span>
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="c_password" class="col-sm-2 col-form-label">Confirm Password</label>
			    <div class="col-sm-10">
			      <input type="password" name="c_password" class="form-control" id="c_password" value="<?php echo $c_password; ?>">
			      <span style="color:red"><?php echo $err_c_password;?></span>
			    </div>
			  </div>

			  <div class="d-flex justify-content-end">
			  	<input type="submit" name="update_password" class="btn btn-primary" value="Save Changes">
			  </div>
				
			</form>
		</div>
		
    </section>
    </main>

    <?php include_once('javascript.php'); ?>
    <?php include_once('index_footer.php'); ?>
	
</body>
</html>
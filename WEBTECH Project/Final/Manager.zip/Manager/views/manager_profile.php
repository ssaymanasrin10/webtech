<?php 
    
    include_once('session_user.php');
    
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>


	<section class="col-md-8">

		<?php 
			if($_SESSION['user_type'] == 'manager')
                {
                  foreach( $managers as $manager )
                  {
                    if( $uname == $manager['uname'] )
                    {
                    	$a_uname = $manager['uname'];
                    	$user    = getUser($uname);
         ?>   

		<div class="container pt-5 pb-5">
			<h1 class="text-center pb-4">P R O F I L E</h1>
			<form action="../controllers/manager_Controller.php" method="POST">
			  <div class="row mb-3">
			    <label for="name" class="col-sm-2 col-form-label">Name</label>
			    <div class="col-sm-10">
			      <input type="text" name="name" class="form-control" id="name" value="<?php echo $manager['name']; ?>">
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="email" class="col-sm-2 col-form-label">Email</label>
			    <div class="col-sm-10">
			      <input type="text" name="email" class="form-control" id="email" value="<?php echo $manager['email']; ?>">
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="address" class="col-sm-2 col-form-label">Address</label>
			    <div class="col-sm-10">
			      <input type="text" name="address" class="form-control" id="address" value="<?php echo $manager['address']; ?>">
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="gender" class="col-sm-2 col-form-label">Gender</label>
			    <div class="col-sm-10">
			      <select id="gender" name="gender" class="form-select">
                    <option <?php if($manager['gender'] == 'Male') echo 'selected'; ?> value="Male">Male</option>
                    <option <?php if($manager['gender'] == 'Female') echo 'selected'; ?> value="Female">Female</option>
                    <option <?php if($manager['gender'] == 'Other') echo 'selected'; ?> value="Other">Other</option>
			      </select>
			    </div>
			  </div>

			  <div class="row mb-3">
			    <label for="b_date" class="col-sm-2 col-form-label">Date of Birth</label>
			    <div class="col-sm-10">
			      <input type="date" name="b_date" class="form-control" id="b_date" value="<?php echo $admin['b_date']; ?>">
			    </div>
			  </div>

			  <input type="hidden" name="id" value="<?php echo $manager["id"]?>" >
			  <input type="hidden" name="uname" value="<?php echo $manager["uname"]?>" >
			  <input type="hidden" name="u_id" value="<?php echo $user["id"]?>" >
			  <input type="hidden" name="password" value="<?php echo $user["password"]?>" >
			  <input type="hidden" name="status" value="<?php echo $user["status"]?>" >

			  <div class="d-flex justify-content-end">
			  	<input type="submit" name="update" class="btn btn-primary" value="Save Changes">
			  </div>
				
			</form>
		</div>

		<?php
                }
              }
            }
		 ?>
		
    </section>
    </main>

    <?php include_once('javascript.php'); ?>
    <?php include_once('index_footer.php'); ?>
	
</body>
</html>
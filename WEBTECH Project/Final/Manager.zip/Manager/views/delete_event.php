<?php 

	require_once ('../controllers/event_Controller.php');
	
	$eid = $_GET['id'];

	deleteEvent($eid);
	header('Location:list_event.php');
 ?>
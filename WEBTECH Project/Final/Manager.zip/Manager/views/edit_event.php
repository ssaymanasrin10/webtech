<?php 
    include_once('session_user.php');

    $eid   = $_GET['id'];
	$event = getEvent($eid);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Event</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>

	<section class="col-md-8 pt-5 pb-5">
		<div class="pb-5">
	        <div class="container d-flex justify-content-center card">
	        	<div class="card-header">
	        		<h2 class="text-center">E D I T &nbsp; &nbsp; E V E N T</h2>
	        	</div>
				<div class="card-body">
					<form method="POST" class="row" action="../controllers/event_Controller.php" enctype="multipart/form-data">

					  <div class="col-12 pb-1">
					    <label for="title" class="form-label">Event Title</label>
					    <input type="text" name="title" class="form-control" id="title" value="<?php echo $event['title'] ;?>">
					  </div>

					  <div class="col-12 pb-1">
					    <label for="description" class="form-label">Description</label>
					    <textarea name="description" class="form-control" rows="8" id="description"><?php echo $event['description'];?></textarea>
					  </div>

					  <div class="col-12 pb-1">
					    <label for="status" class="form-label">Status</label>
					    <select id="status" name="status" class="form-select">
						<option selected disabled value="NULL">Select Status</option>
		                    <option <?php if($event['status'] == 1 ) echo 'selected'; ?> value="1">Active</option>
		                    <option <?php if($event['status'] == 2 ) echo 'selected'; ?> value="2">In-Active</option>
					    </select>
					  </div>

					  <div class="col-6 pb-1">
					  	<label for="img" class="form-label">Event Picture</label><br>
					  	<img style="height: 100px; width: 100px;" src="<?php echo $event['img'];?>">
					  	<input type="file" name="img" class="form-control" id="img">
					  </div>

					  <input type="hidden" name="id" value="<?php echo $event["id"]?>" >
					  <input type="hidden" name="prev_image" value="<?php echo $event["img"]?>" >
					  
					  <div class="col-12 pt-2 pb-1">
					    <input type="submit" name="edit_event" class="btn btn-primary" value="Submit">
					  </div>

					</form>
				</div>
			</div>
		</div>
    </section>
</main>

	<?php include_once('javascript.php'); ?>
	<?php include_once('index_footer.php'); ?>
	
</body>
</html>
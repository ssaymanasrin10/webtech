<header>
	<div style="padding-bottom: 150px;">

        <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <h2>E V E N T &nbsp; &nbsp; M A N A G E M E N T</h2>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link" aria-current="page" href="home.php">Home</a>
                        <a class="nav-link" href="#about">About Us</a>
                        <a class="nav-link" href="#organizer">Organaizer</a>
                        <a class="nav-link" href="#contact">Contact Us</a>
                        <a class="nav-link" href="registration.php">Registration</a>
                        <a class="nav-link" href="login.php">Login</a>
                    </div>
                </div>
            </div>
        </nav>

	</div>
</header>
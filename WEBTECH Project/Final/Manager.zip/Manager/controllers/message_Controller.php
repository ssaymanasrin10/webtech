<?php

	if(!isset($_SESSION)) 
    { 
        session_start(); 
    }

	require_once '../model/database.php';

	if(isset($_POST['submit']))
	{
		insertMessage();
	}

	function getAllMessage()
	{
		$query    = "SELECT * FROM `messages` order by id desc";
		$messages = get($query);
		return $messages;
	}

	function getMessage($id)
	{
		$query="SELECT * FROM messages WHERE id=$id";
		$message=get($query);
		return $message[0];
	}

	function deleteMessage($id)
	{
		$query   = "DELETE FROM messages WHERE id=$id";
    	$message = get($query);
		return $message[0];	
	}

	function insertMessage()
	{
		$name        = $_POST['name'];
		$email       = $_POST['email'];
		$message     = $_POST['message'];

		$query = "INSERT INTO messages VALUEs(NULL, '$name', '$email', '$message')";

		execute($query);

		header("Location:../views/home.php");
	}
	
 ?>
<?php

	if(!isset($_SESSION)) 
    { 
        session_start(); 
    }

	require_once '../model/database.php';

	if(isset($_GET['req']) && $_GET['req'] == 'add_event')
	{
		insertEvent();
	}

	elseif(isset($_POST['edit_event']))
	{
		editEvent();
	}

	function getAllEvent()
	{
		$query  = "SELECT * FROM `event` order by id desc";
		$events = get($query);
		return $events;
	}

	function getEvent($id)
	{
		$query = "SELECT * FROM event WHERE id=$id";
		$event = get($query);
		return $event[0];
	}

	function deleteEvent($id)
	{
		$query = "DELETE FROM event WHERE id=$id";
    	$event = get($query);
		return $event[0];	
	}

	function insertEvent()
	{
		$title       = $_SESSION['title'];
		$description = $_SESSION['description'];
		$img         = $_SESSION['img'];
		$status      = $_SESSION['status'];

		$query = "INSERT INTO event VALUEs(NULL, '$title', '$description', '$status', '$img')";

		execute($query);

		header("Location:../views/list_event.php");
	}

	function editEvent()
	{
		$img         = $_POST["prev_image"];
		$id          = $_POST['id'];
		$title       = $_POST['title'];
		$description = $_POST['description'];
		$status      = $_POST['status'];

		if(file_exists($_FILES['img']['tmp_name']) || is_uploaded_file($_FILES['img']['tmp_name'])) 
		{
			$target_dir  = "../storage/event_image/";
			$target_file = $target_dir . basename($_FILES["img"]["name"]);
			move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
			$img = $target_file;
		}

		$query = "UPDATE event SET title='$title', description='$description', status='$status', img='$img' WHERE id=$id ";

		execute($query);

		header("Location:../views/list_event.php");
	}
	
 ?>
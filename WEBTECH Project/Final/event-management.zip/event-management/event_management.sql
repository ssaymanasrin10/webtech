-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2021 at 07:32 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `b_date` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `uname`, `address`, `b_date`, `gender`, `img`) VALUES
(1, 'Sayma Nasrin', 'sayma@gmail.com', 'sayma', 'Basundhora, Dhaka', '1997-09-06', 'Female', '../storage/admin_image/sayma.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `b_date` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `uname`, `address`, `b_date`, `gender`, `img`) VALUES
(2, 'Arhab Safwan', 'arhab@gmail.com', 'arhab', 'Dhaka', '2021-04-06', 'Male', '../storage/customer_image/arhab.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '2' COMMENT '2 for in-active & 1 for active',
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `title`, `description`, `status`, `img`) VALUES
(1, 'Widding', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ', '1', '../storage/event_image/widding.jpg'),
(2, 'Birthday', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ', '1', '../storage/event_image/birthday.jpg'),
(3, 'Wedding Aneversary', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ', '1', '../storage/event_image/widding_aneversary.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 2 COMMENT '2 for inactive and 1 for active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `uname`, `password`, `user_type`, `status`) VALUES
(1, 'Sayma Nasrin', 'sayma', 'ed7a90d451dfbd11bcaf4274d59404f0e3f0e2b9', 'admin', 1),
(2, 'Arhab Safwan', 'arhab', '9fa2438460d3516162cc4edd9a01f63697a13674', 'customer', 1),
(3, 'Mahia Islam', 'mahia', '9fa2438460d3516162cc4edd9a01f63697a13674', 'manager', 1),
(24, 'Arhab Safwan', 'arhab1', 'ed7a90d451dfbd11bcaf4274d59404f0e3f0e2b9', 'manager', 1),
(25, 'Sayma Nasrin', 'sayma1', 'ed7a90d451dfbd11bcaf4274d59404f0e3f0e2b9', 'manager', 1);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `b_date` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `name`, `email`, `uname`, `address`, `b_date`, `gender`, `img`) VALUES
(1, 'Mahia Islam', 'mahia@gmail.com', 'mahia', 'Dhaka', '2021-03-27', 'Female', '../storage/manager_image/mahia.jpg'),
(15, 'Arhab Safwan', 'arhab@gmail.com', 'arhab1', 'Dhaka', '1997-01-28', 'Male', '../storage/manager_image/arhab.jpg'),
(16, 'Sayma Nasrin', 'sayma@gmail.com', 'sayma1', 'Dhaka', '1997-01-21', 'Female', '../storage/manager_image/sayma.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`) VALUES
(1, 'Borhan', 'borhan@gmail.com', 'Hi Buddy!!!'),
(2, 'Sayma', 'sayma@gmail.com', 'Sorry!!'),
(3, 'Sadia Afrin', 'sadia@gmail.com', 'I want to know more.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

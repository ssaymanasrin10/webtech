<?php

	if(!isset($_SESSION)) 
    { 
        session_start(); 
    }

	require_once '../model/database.php';

	if(isset($_GET['req']) && $_GET['req'] == 'add_manager')
	{
		insertManager();
	}

	elseif(isset($_POST['edit_manager']))
	{
		editManager();
	}

	function getAllManager()
	{
		$query    = "SELECT * FROM `manager` order by name asc";
		$managers = get($query);
		return $managers;
	}

	function getManager($id)
	{
		$query   = "SELECT * FROM manager WHERE id=$id";
		$manager = get($query);
		return $manager[0];
	}

	function deleteManager($id)
	{
		$query   = "DELETE FROM manager WHERE id=$id";
    	$manager = get($query);
		return $manager[0];	
	}

	function searchManager($key)
	{
		$query="SELECT * FROM manager WHERE name LIKE '%$key%' order by name asc";
		$manager = get($query);
		if($manager)
    	{
    		return $manager[0];
    	}
    	else
    	{
    		$msg = 'Not Found';
    		return $msg;
    	}	
	}

	function insertManager()
	{
		$name        = $_SESSION['name'];
		$email       = $_SESSION['email'];
		$uname       = $_SESSION['uname'];
		$address     = $_SESSION['address'];
		$password    = $_SESSION['password'];
		$gender      = $_SESSION['gender'];
		$b_date      = $_SESSION['b_date'];
		$img         = $_SESSION['img'];
		$user_type   = 'manager';
		$status      = $_SESSION['status'];

		$query  = "INSERT INTO manager VALUEs(NULL, '$name', '$email', '$uname', '$address', '$b_date', '$gender', '$img')";
		$query2 = "INSERT INTO login VALUEs(NULL, '$name', '$uname', '$password', '$user_type', '$status')";

		execute($query);
		execute($query2);

		header("Location:../views/list_manager.php");
	}

	function editManager()
	{
		$img         = $_POST["prev_image"];
		$id          = $_POST['id'];
		$name        = $_POST['name'];
		$email       = $_POST['email'];
		$gender      = $_POST['gender'];
		$b_date      = $_POST['b_date'];
		$address     = $_POST['address'];	
		
		$u_id        = $_POST['u_id'];
		$uname       = $_POST['uname'];
		$password    = $_POST['password'];	
		$user_type   = 'manager';
		$status      = $_POST['status'];

		if(file_exists($_FILES['img']['tmp_name']) || is_uploaded_file($_FILES['img']['tmp_name'])) 
		{
			$target_dir  = "../storage/manager_image/";
			$target_file = $target_dir . basename($_FILES["img"]["name"]);
			move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
			$img = $target_file;
		}

		$query  = "UPDATE manager SET name='$name', email='$email', uname='$uname', address='$address', b_date='$b_date', gender='$gender', img='$img' WHERE id=$id";
		$query2 = "UPDATE login SET name='$name', uname='$uname', password='$password', user_type='$user_type', status='$status' WHERE id=$u_id ";

		execute($query);
		execute($query2);

		header("Location:../views/list_manager.php");
	}
	
 ?>
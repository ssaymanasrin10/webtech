<?php include_once('session_user.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>All Event Information</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>

	<section class="col-md-8 pb-5 pt-5">
		<h1 class="text-center pt-2">ALL EVENT INFORMATION</h1>
		<div class="table-responsive">
			<table class="table text-center table-hover">
			  <thead class="table-dark">
			    <tr>
					<th scope="col">#SL</th>
					<th scope="col">Image</th>
			        <th scope="col">Title</th>
					<th scope="col">Description</th>
					<th scope="col">Status</th>
					<th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			    <?php

					$i = 0;
					foreach($events as $event)
					{
						$id      		= $event["id"];
						$img     		= $event["img"];
						$title    		= $event["title"];
						$description   	= $event["description"];
						$status         = $event['status'];
						$i++;
					?>
					
				<tr>
					<td><?php echo $i ; ?></td>
					<td><?php
						if(!$img)
						{ ?>
							<img style="height: 40px; width: 50px;" src="../storage/default.png">
				<?php	}
						else
						{ ?>
							<img style="height: 40px; width: 50px;" src="<?php echo $img ;?>">
				<?php	}

					  ?></td>
					<td><?php echo $title ; ?></td>
					<td><?php echo $description ; ?></td>
					<td><?php
						if($status == 1)
						{ ?>
							<span class="badge bg-success">Active</span>
				<?php   }
						else
						{ ?>
							<span class="badge bg-danger">In-Active</span>
				<?php	} ?>
					</td>
					<td>
						<div>
	                        <a style="text-decoration: none;" href="edit_event.php?id=<?php echo $id; ?>">EDIT</a> | <a style="text-decoration: none;" href="" data-bs-toggle="modal" data-bs-target="#delete<?php echo $id; ?>">DELETE</a>
	                    </div>
					</td>
				</tr>

				<!-- Modal -->

				<div class="modal fade" id="delete<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title" id="exampleModalLabel">Do you want to Delete <?php echo $title; ?> event?</h5>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				      </div>
				      <div class="modal-body d-flex justify-content-between">
				      	<a href="delete_event.php?id=<?php echo $id; ?>" class="btn btn-danger">Yes</a>
				        <button type="button" class="btn btn-success" data-bs-dismiss="modal">No</button>
				      </div>
				    </div>
				  </div>
				</div>

				<!-- Modal -->
	         <?php
	     			}
				?>
			  </tbody>
			</table>
		</div>
    </section>
</main>

	<?php include_once('javascript.php'); ?>
    <?php include_once('index_footer.php'); ?>
	
</body>
</html>
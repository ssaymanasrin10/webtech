<?php include_once('session_user.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Manager</title>
  <?php include_once('bootstrap.php'); ?>
</head>
<body>
  <header>
    <div class="pb-5">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <div class="container">
            <form class="d-flex">
                <input class="form-control me-2" type="text" placeholder="Search" aria-label="Search" id="search_input">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                <div class="navbar-nav">
                    <span class="nav-link" style="color : white;">Logged in as</span>
                    <a class="nav-link" style="color : white;" aria-current="page" href="">
                      <?php

                        if($_SESSION['user_type'] == 'manager')
                        {
                          foreach($managers as $manager)
                          {
                            if( $uname == $manager['uname'] )
                            {
                              echo $manager['name'];
                            } 
                          }
                        }

                      ?>
                     </a>
                    <a class="nav-link active" aria-current="page" href="logout.php">Logout</a>
                </div>
            </div>
          </div>
        </nav>
    </div>
  </header>
  <?php include_once('javascript.php'); ?>
  <?php include_once('index_footer.php'); ?>
  
</body>
</html>


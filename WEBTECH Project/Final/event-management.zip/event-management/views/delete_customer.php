<?php 

	require_once ('../controllers/customer_Controller.php');
	require_once ('../controllers/login_Controller.php');

	$cid      = $_GET['id'];
	$customer = getCustomer($cid);
	$uname    = $customer['uname'];

	deleteCustomer($cid);
	deleteUser($uname);
	header('Location:list_customer.php');
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1 class="text-center pt-2">ALL MANAGER INFORMATION</h1>
	<div class="table-responsive">
		<table class="table text-center table-hover">
	  <thead class="table-dark">
	    <tr>
			<th scope="col">#SL</th>
			<th scope="col">Image</th>
	        <th scope="col">Name</th>
			<th scope="col">Email</th>
			<th scope="col">Address</th>
			<th scope="col">Gender</th>
			<th scope="col">Birth Date</th>
			<th scope="col">Status</th>
			<th scope="col">Action</th>
	    </tr>
	  </thead>
<?php
	include_once('session_user.php');
	
	$key     = $_GET['sk'];

	$serverName="localhost";
	$userName="root";
	$password="";
	$dbName="event_management";

	$conn = mysqli_connect( $serverName, $userName, $password, $dbName);
	$query="SELECT * FROM manager WHERE name LIKE '%$key%' order by name asc";

    $result=mysqli_query($conn,$query);

    $i = 0 ;
  
	while($manager = mysqli_fetch_assoc($result))
    {
    	$id      		= $manager["id"];
		$img     		= $manager["img"];
		$name    		= $manager["name"];
		$email   		= $manager["email"];
		$address 		= $manager["address"];
		$gender  		= $manager["gender"];
		$b_date         = $manager["b_date"];
		$manager_uname  = $manager["uname"];
		$user           = getUser($manager_uname);
		$status         = $user['status'];
		$i++ ;
		?>
		<tbody>		
		<tr>
			<td><?php echo $i ; ?></td>
			<td><?php
				if( $img == '../storage/manager_image/')
				{ ?>
					<img style="height: 40px; width: 50px;" src="../storage/default.png">
		<?php	}
				else
				{ ?>
					<img style="height: 40px; width: 50px;" src="<?php echo $img ;?>">
		<?php	}

			  ?></td>
			<td><?php echo $name ; ?></td>
			<td><?php echo $email ; ?></td>
			<td><?php echo $address ; ?></td>
			<td><?php echo $gender ; ?></td>
			<td><?php echo $b_date ; ?></td>
			<td><?php
				if($status == 1)
				{ ?>
					<span class="badge bg-success">Active</span>
		<?php   }
				else
				{ ?>
					<span class="badge bg-danger">In-Active</span>
		<?php	} ?>
			</td>
			<td>
				<div>
                    <a style="text-decoration: none;" href="edit_manager.php?id=<?php echo $id; ?>">EDIT</a> | <a style="text-decoration: none;" href="" data-bs-toggle="modal" data-bs-target="#deleteList<?php echo $id; ?>">DELETE</a>
                </div>
			</td>
		</tr>

		<!-- Modal -->

		<div class="modal fade" id="deleteList<?php echo $id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Do you want to Delete <?php echo $name; ?>?</h5>
		        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		      </div>

		      <div class="modal-body d-flex justify-content-between">
		      	<a href="delete_manager.php?id=<?php echo $id; ?>" class="btn btn-danger">Yes</a>
		        <button type="button" class="btn btn-success" data-bs-dismiss="modal">No</button>
		      </div>

		    </div>
		  </div>
		</div>

		<!-- Modal -->

	  	</tbody>

<?php    }
?>
	</div>

</body>
</html>
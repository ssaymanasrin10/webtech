<?php 
    
    include_once('session_user.php');
    
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profile</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>

	<section class="col-md-8">

		<?php 
			if($_SESSION['user_type'] == 'admin')
                {
                  foreach( $admins as $admin )
                  {
                    if( $uname == $admin['uname'] )
                    {
         ?>   

		<div class="container pt-5 pb-5">
			<div class="pb-5">
				<h1 class="text-center pb-4">P I C T U R E</h1>
				<form action="../controllers/admin_Controller.php" method="POST" enctype="multipart/form-data">

					<div class="row mb-3">
				    <div class="col-sm-10">
				    	<?php if($admin['img']) { ?> <img class="w-50" style="border-radius: 20px;" src="<?php echo $admin['img']; ?>"> <?php } else { ?> <img src="../storage/default.png"> <?php } ?>
				    </div>
				  </div>

				  <div class="row mb-3">
				    <div class="col-sm-10">
				      <input type="file" name="img" class="form-control">
				    </div>
				  </div>

				  <input type="hidden" name="id" value="<?php echo $admin["id"]?>" >
				  <input type="hidden" name="name" value="<?php echo $admin["name"]?>" >
				  <input type="hidden" name="uname" value="<?php echo $admin["uname"]?>" >
				  <input type="hidden" name="email" value="<?php echo $admin["email"]?>" >
				  <input type="hidden" name="address" value="<?php echo $admin["address"]?>" >
				  <input type="hidden" name="prev_image" value="<?php echo $admin["img"]?>" >
				  <input type="hidden" name="gender" value="<?php echo $admin["gender"]?>" >
				  <input type="hidden" name="b_date" value="<?php echo $admin["b_date"]?>" >

				  <div>
				  	<input type="submit" name="change_picture" class="btn btn-primary" value="Save Changes">
				  </div>
					
				</form>
			</div>
		</div>

		<?php
                }
              }
            }
		 ?>
		
    </section>
    </main>

    <?php include_once('javascript.php'); ?>
    <?php include_once('index_footer.php'); ?>
	
</body>
</html>
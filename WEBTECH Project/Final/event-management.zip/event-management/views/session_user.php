<?php
	if(!isset($_SESSION)) 
    { 
        session_start(); 
    }

    if(!isset($_COOKIE['loggedinuser']))
    {
        header("Location:login.php");
    }
    
    $c_uname           = $_COOKIE['loggedinuser'];
    $_SESSION['uname'] = $c_uname;
    $uname             = $_SESSION['uname'];

    require_once '../controllers/admin_Controller.php';
    $admins    = getAllAdmin();
    require_once '../controllers/manager_Controller.php';
    $managers  = getAllManager();
    require_once '../controllers/customer_Controller.php';
    $customers = getAllCustomer();
    require_once ('../controllers/login_Controller.php');
    $users = getAllUser();
    require_once ('../controllers/message_Controller.php');
    $messages = getAllMessage();
    require_once ('../controllers/event_Controller.php');
    $events = getAllEvent();
?>
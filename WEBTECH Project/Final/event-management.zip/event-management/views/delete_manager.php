<?php 

	require_once ('../controllers/manager_Controller.php');
	require_once ('../controllers/login_Controller.php');

	$mid = $_GET['id'];
	$manager = getManager($mid);
	$uname = $manager['uname'];

	deleteManager($mid);
	deleteUser($uname);
	header('Location:list_manager.php');
 ?>
<?php 
    include_once('session_user.php');

   	require_once ('../controllers/manager_Controller.php');
	require_once ('../controllers/login_Controller.php');

	$mid = $_GET['id'];
	$manager = getManager($mid);
	$uname = $manager['uname'];
	$user = getUser($uname);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Manager</title>
	<?php include_once('bootstrap.php'); ?>
</head>
<body>
	<?php include_once('header.php'); ?>

	<section class="col-md-8 pt-5 pb-5">
		<div class="pb-5">
            <div class="container d-flex justify-content-center card">
            	<div class="card-header">
            		<h2 class="text-center">E D I T &nbsp; &nbsp; M A N A G E R</h2>
            	</div>
				<div class="card-body">
					<form method="POST" class="row" action="../controllers/manager_Controller.php" enctype="multipart/form-data">

					  <div class="col-md-6 pb-1">
					    <label for="name" class="form-label">Name</label>
					    <input type="text" name="name" class="form-control" id="name" value="<?php echo $manager['name'];?>">
					  </div>

					  <div class="col-md-6 pb-1">
					    <label for="email" class="form-label">Email</label>
					    <input type="text" name="email" class="form-control" id="email" value="<?php echo $manager['email'];?>">
					  </div>

					  <div class="col-md-6 pb-1">
					    <label for="address" class="form-label">Address</label>
					    <textarea name="address" class="form-control h-25" id="address"><?php echo $manager['address'];?></textarea>
					  </div>
					  
					  <div class="col-md-6 pb-1">
					    <label for="gender" class="form-label">Gender</label>
					    <select id="gender" name="gender" class="form-select">
		                    <option <?php if($manager['gender'] == 'Male') echo 'selected'; ?> value="Male">Male</option>
		                    <option <?php if($manager['gender'] == 'Female') echo 'selected'; ?> value="Female">Female</option>
		                    <option <?php if($manager['gender'] == 'Other') echo 'selected'; ?> value="Other">Other</option>
					    </select>
					  </div>

					  <div class="col-md-6 pb-1">
					    <label for="status" class="form-label">Status</label>
					    <select id="status" name="status" class="form-select">
		                    <option <?php if($user['status'] == 1 ) echo 'selected'; ?> value="1">Active</option>
		                    <option <?php if($user['status'] == 2 ) echo 'selected'; ?> value="2">In-Active</option>
					    </select>
					  </div>

					  <div class="col-md-6 pb-1">
					    <label for="b_date" class="form-label">Birth Date</label>
					    <input type="date" name="b_date" class="form-control" id="b_date" value="<?php echo $manager['b_date'];?>">
					  </div>

					  <div class="col-6 pb-1">
					  	<label for="img" class="form-label">Profile Picture</label><br>
					  	<img style="height: 100px; width: 100px;" src="<?php echo $manager['img'];?>">
					  	<input type="file" name="img" class="form-control" id="img">
					  </div>

					  <input type="hidden" name="id" value="<?php echo $manager["id"]?>" >
					  <input type="hidden" name="uname" value="<?php echo $manager["uname"]?>" >
					  <input type="hidden" name="prev_image" value="<?php echo $manager["img"]?>" >
					  <input type="hidden" name="u_id" value="<?php echo $user["id"]?>" >
					  <input type="hidden" name="password" value="<?php echo $user["password"]?>" >
					  
					  <div class="col-12 pt-2 pb-1">
					    <input type="submit" name="edit_manager" class="btn btn-primary" value="Save Changes">
					  </div>

					</form>
				</div>
			</div>
		</div>
    </section>
</main>

        <?php include_once('javascript.php'); ?>
        <?php include_once('index_footer.php'); ?>
	
</body>
</html>